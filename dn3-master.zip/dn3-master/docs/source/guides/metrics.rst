#################
Metrics
#################
*Metrics are how your work gets evaluated. Here we talk about some of the tools DN3 provides to do this well.*

.. contents:: :local:

sklearn
-------
